(function () {
  const INBOXES = {
    support: 'support@heychathq.com',
    partnerships: 'partnerships@heychathq.com',
    privacy: 'support@heychathq.com'
  };

  document.querySelectorAll('form[data-contact-form]').forEach(function (form) {
    const status = form.querySelector('.form-status');

    function show(kind, msg) {
      if (!status) return;
      status.className = 'form-status ' + kind;
      status.textContent = msg;
    }

    form.addEventListener('submit', function (e) {
      e.preventDefault();

      const data = {};
      new FormData(form).forEach(function (v, k) {
        data[k] = v;
      });

      if (!data.email || !/^\S+@\S+\.\S+$/.test(data.email)) {
        show('err', 'Please enter a valid email address.');
        return;
      }

      const type = data.topic || form.getAttribute('data-inbox') || 'support';
      const inbox = INBOXES[type] || INBOXES.support;
      const endpoint = form.getAttribute('data-endpoint');

      if (endpoint) {
        fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/json' },
          body: JSON.stringify(data)
        })
        .then(function (r) {
          if (!r.ok) throw new Error('Request failed');
          form.reset();
          show('ok', 'Thanks! Your message has been sent. We reply within 2 business days.');
        })
        .catch(function () {
          show('err', 'Could not send right now. Please email ' + inbox + ' directly.');
        });

        return;
      }

      const subject = encodeURIComponent((data.subject || 'Heychat ' + type + ' request'));
      const body = encodeURIComponent(
        Object.keys(data).map(function (k) {
          return k + ': ' + data[k];
        }).join('\n')
      );

      window.location.href = 'mailto:' + inbox + '?subject=' + subject + '&body=' + body;
      show('ok', 'Opening your email app to send this to ' + inbox + '…');
    });
  });
})();